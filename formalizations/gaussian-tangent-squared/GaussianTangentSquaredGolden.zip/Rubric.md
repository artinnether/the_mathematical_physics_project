# Rúbrica — integral gaussiana con polos tangentes dobles

8 criterios; peso +1 cada uno; texto en inglés, con la misma notación Unicode utilizada en las rúbricas previas.

1. For every real α>0, b>0 and 0<δ<min(θ,π/2−θ), the submitted Lean proof establishes a finite real N→∞ limit of Σ_{k=−N}^{N}∫_{[−π/2,−θ−δ]∪[−θ+δ,θ−δ]∪[θ+δ,π/2]}exp(−α(kπ+t)²)cos⁴(kπ+t)/(sin²(kπ+t)−b²cos²(kπ+t))²dt, where θ=arctan b.

2. For every real α>0 and b>0, the submitted Lean proof establishes lim_{δ→0+}[J(δ)−M/(2b²D²δ)]=√(π/α)/D²{1+Σ_{n=1}^{∞}[(1+3b²)sin(2nθ)/b³−2n cos(2nθ)/b²]exp(−n²/α)}, where θ=arctan b, D=1+b², M=Σ_{k∈ℤ}[exp(−α(kπ+θ)²)+exp(−α(kπ−θ)²)], and J(δ) is the finite N→∞ limit of Σ_{k=−N}^{N}∫_{[−π/2,−θ−δ]∪[−θ+δ,θ−δ]∪[θ+δ,π/2]}exp(−α(kπ+t)²)cos⁴(kπ+t)/(sin²(kπ+t)−b²cos²(kπ+t))²dt.

3. For every real α>0 and b>0, the submitted Lean proof establishes P′(b)=2bH, where θ=arctan b, D=1+b², P(y)=−√(π/α)/(1+y²){1+(2/y)Σ_{n=1}^{∞}sin(2n arctan y)exp(−n²/α)} for y>0, and H=√(π/α)/D²{1+Σ_{n=1}^{∞}[(1+3b²)sin(2nθ)/b³−2n cos(2nθ)/b²]exp(−n²/α)}.

4. For every real α>0 and b>0, the submitted Lean proof establishes M′(b)=Σ_{k∈ℤ}[−2α(kπ+θ)exp(−α(kπ+θ)²)+2α(kπ−θ)exp(−α(kπ−θ)²)]/D, where θ=arctan b, D=1+b², and M(y)=Σ_{k∈ℤ}[exp(−α(kπ+arctan y)²)+exp(−α(kπ−arctan y)²)] for y>0.

5. For every real α>0, b>0 and ε>0, the submitted Lean proof establishes absolute Lebesgue integrability on ℝ of x↦exp(−αx²)cos⁴(x)/(sin²(x)−b²cos²(x)+iεcos²(x))², where i²=−1.

6. For every real α>0 and b>0, the submitted Lean proof establishes lim_{ε→0+}∫_ℝexp(−αx²)cos⁴(x)/(sin²(x)−b²cos²(x)+iεcos²(x))²dx=H+iQ, where i²=−1, the integral is the whole-line complex Lebesgue integral, θ=arctan b, D=1+b², H=√(π/α)/D²{1+Σ_{n=1}^{∞}[(1+3b²)sin(2nθ)/b³−2n cos(2nθ)/b²]exp(−n²/α)}, Q=π(1+3b²)M/(4b³D²)−πL/(4b²D), M=Σ_{k∈ℤ}[exp(−α(kπ+θ)²)+exp(−α(kπ−θ)²)], and L=Σ_{k∈ℤ}[−2α(kπ+θ)exp(−α(kπ+θ)²)+2α(kπ−θ)exp(−α(kπ−θ)²)]/D.

7. For every real α>0, b>0 and 0<r<1, the submitted Lean proof establishes absolute Lebesgue integrability on ℝ of x↦exp(−αx²){1+Σ_{n=1}^{∞}rⁿ[(1+3b²)sin(2nθ)/b³−2n cos(2nθ)/b²]cos(2nx)}/D², where θ=arctan b and D=1+b².

8. For every real α>0 and b>0, the submitted Lean proof establishes lim_{r→1−}∫_ℝexp(−αx²){1+Σ_{n=1}^{∞}rⁿ[(1+3b²)sin(2nθ)/b³−2n cos(2nθ)/b²]cos(2nx)}/D²dx=√(π/α)/D²{1+Σ_{n=1}^{∞}[(1+3b²)sin(2nθ)/b³−2n cos(2nθ)/b²]exp(−n²/α)}, where θ=arctan b, D=1+b², and the integrals are whole-line real Lebesgue integrals for 0<r<1.
